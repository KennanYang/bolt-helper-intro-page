class BoltPromptMonitor {
  constructor() {
    this.isMonitoring = false;
    this.lastPrompt = '';
    this.promptSelectors = [
      'textarea[placeholder*="prompt"]',
      'textarea[placeholder*="提示"]',
      'textarea[placeholder*="输入"]',
      'input[placeholder*="prompt"]',
      'input[placeholder*="提示"]',
      'input[placeholder*="输入"]',
      '[contenteditable="true"]',
      'textarea',
      'input[type="text"]'
    ];
    this.init();
  }

  init() {
    this.startMonitoring();
    this.observeDOM();
    console.log('Bolt Prompt Monitor 已启动');
  }

  startMonitoring() {
    if (this.isMonitoring) return;
    
    this.isMonitoring = true;
    
    // 监听网络请求
    this.interceptFetch();
    this.interceptXHR();
    
    // 监听输入框变化
    this.monitorInputs();
    
    // 监听键盘事件
    this.monitorKeyboard();
  }

  interceptFetch() {
    const originalFetch = window.fetch;
    
    window.fetch = async (...args) => {
      const response = await originalFetch.apply(this, args);
      
      try {
        const url = args[0];
        const options = args[1] || {};
        
        if (this.isRelevantRequest(url, options)) {
          await this.handleRequest(url, options);
        }
      } catch (error) {
        console.error('处理fetch请求时出错:', error);
      }
      
      return response;
    };
  }

  interceptXHR() {
    const originalOpen = XMLHttpRequest.prototype.open;
    const originalSend = XMLHttpRequest.prototype.send;
    
    XMLHttpRequest.prototype.open = function(method, url, ...args) {
      this._url = url;
      this._method = method;
      return originalOpen.apply(this, [method, url, ...args]);
    };
    
    XMLHttpRequest.prototype.send = function(data) {
      if (this._url && this._method && this.isRelevantRequest(this._url, { method: this._method, body: data })) {
        this.handleRequest(this._url, { method: this._method, body: data });
      }
      return originalSend.apply(this, [data]);
    };
  }

  isRelevantRequest(url, options) {
    if (!url || !options) return false;
    
    const urlStr = url.toString().toLowerCase();
    const method = (options.method || 'GET').toUpperCase();
    
    // 检查是否是相关的API请求
    const relevantPatterns = [
      '/api/chat',
      '/api/generate',
      '/api/completion',
      '/chat',
      '/generate',
      '/completion',
      'openai',
      'anthropic',
      'claude'
    ];
    
    const isRelevantUrl = relevantPatterns.some(pattern => urlStr.includes(pattern));
    const isPostRequest = method === 'POST';
    const hasBody = options.body;
    
    return isRelevantUrl && isPostRequest && hasBody;
  }

  async handleRequest(url, options) {
    try {
      let prompt = '';
      
      if (options.body) {
        let bodyData;
        
        if (typeof options.body === 'string') {
          try {
            bodyData = JSON.parse(options.body);
          } catch {
            bodyData = { content: options.body };
          }
        } else {
          bodyData = options.body;
        }
        
        // 从不同的数据结构中提取提示词
        prompt = this.extractPromptFromData(bodyData);
      }
      
      if (prompt && prompt.trim() && prompt !== this.lastPrompt) {
        await this.savePrompt(prompt.trim());
        this.lastPrompt = prompt.trim();
      }
    } catch (error) {
      console.error('处理请求数据时出错:', error);
    }
  }

  extractPromptFromData(data) {
    if (!data || typeof data !== 'object') return '';
    
    // 常见的提示词字段名
    const promptFields = [
      'prompt',
      'message',
      'content',
      'text',
      'input',
      'query',
      'question',
      'messages'
    ];
    
    // 直接查找字段
    for (const field of promptFields) {
      if (data[field]) {
        if (typeof data[field] === 'string') {
          return data[field];
        } else if (Array.isArray(data[field])) {
          // 处理消息数组格式
          const lastMessage = data[field][data[field].length - 1];
          if (lastMessage && lastMessage.content) {
            return lastMessage.content;
          }
        }
      }
    }
    
    // 递归查找嵌套对象
    for (const key in data) {
      if (typeof data[key] === 'object') {
        const nestedPrompt = this.extractPromptFromData(data[key]);
        if (nestedPrompt) return nestedPrompt;
      }
    }
    
    return '';
  }

  monitorInputs() {
    // 定期检查输入框
    setInterval(() => {
      this.checkInputs();
    }, 1000);
  }

  checkInputs() {
    for (const selector of this.promptSelectors) {
      const elements = document.querySelectorAll(selector);
      
      elements.forEach(element => {
        if (!element._promptMonitored) {
          element._promptMonitored = true;
          
          // 监听输入事件
          element.addEventListener('input', (e) => {
            this.handleInputChange(e.target);
          });
          
          // 监听粘贴事件
          element.addEventListener('paste', (e) => {
            setTimeout(() => {
              this.handleInputChange(e.target);
            }, 100);
          });
        }
      });
    }
  }

  handleInputChange(element) {
    const value = element.value || element.textContent || '';
    
    if (value.trim() && value.trim().length > 10 && value.trim() !== this.lastPrompt) {
      // 延迟保存，避免频繁触发
      clearTimeout(this.inputTimeout);
      this.inputTimeout = setTimeout(() => {
        this.savePrompt(value.trim());
        this.lastPrompt = value.trim();
      }, 2000);
    }
  }

  monitorKeyboard() {
    document.addEventListener('keydown', (e) => {
      // 监听Enter键提交
      if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
        const activeElement = document.activeElement;
        if (activeElement && this.isPromptInput(activeElement)) {
          const value = activeElement.value || activeElement.textContent || '';
          if (value.trim()) {
            this.savePrompt(value.trim());
            this.lastPrompt = value.trim();
          }
        }
      }
    });
  }

  isPromptInput(element) {
    if (!element) return false;
    
    const tagName = element.tagName.toLowerCase();
    const placeholder = (element.placeholder || '').toLowerCase();
    const className = (element.className || '').toLowerCase();
    const id = (element.id || '').toLowerCase();
    
    const promptKeywords = ['prompt', '提示', '输入', 'chat', 'message'];
    
    return (
      (tagName === 'textarea' || tagName === 'input') &&
      promptKeywords.some(keyword => 
        placeholder.includes(keyword) || 
        className.includes(keyword) || 
        id.includes(keyword)
      )
    ) || element.contentEditable === 'true';
  }

  async savePrompt(content) {
    try {
      const prompt = {
        id: this.generateId(),
        content: content,
        timestamp: Date.now(),
        url: window.location.href,
        createdAt: Date.now(),
        updatedAt: Date.now()
      };
      
      // 获取现有数据
      const result = await chrome.storage.local.get(['promptHistory']);
      const history = result.promptHistory || [];
      
      // 检查是否已存在相同内容
      const exists = history.some(item => item.content === content);
      if (exists) return;
      
      // 添加新提示词
      history.unshift(prompt);
      
      // 限制历史记录数量（最多保存1000条）
      if (history.length > 1000) {
        history.splice(1000);
      }
      
      // 保存到存储
      await chrome.storage.local.set({ promptHistory: history });
      
      console.log('提示词已保存:', content.substring(0, 50) + '...');
      
      // 发送消息给popup（如果打开的话）
      chrome.runtime.sendMessage({
        type: 'PROMPT_SAVED',
        prompt: prompt
      }).catch(() => {
        // 忽略错误，popup可能没有打开
      });
      
    } catch (error) {
      console.error('保存提示词失败:', error);
    }
  }

  generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }

  observeDOM() {
    // 观察DOM变化，处理动态加载的内容
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === 'childList') {
          mutation.addedNodes.forEach((node) => {
            if (node.nodeType === Node.ELEMENT_NODE) {
              // 检查新添加的输入框
              setTimeout(() => {
                this.checkInputs();
              }, 500);
            }
          });
        }
      });
    });
    
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }
}

// 等待页面加载完成后启动监控
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    new BoltPromptMonitor();
  });
} else {
  new BoltPromptMonitor();
}