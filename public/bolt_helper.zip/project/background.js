// 后台脚本 - 处理数据保存和管理
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'SAVE_PROMPT') {
    savePrompt(message.data);
  } else if (message.type === 'GET_PROMPTS') {
    getPrompts().then(prompts => {
      sendResponse({ prompts });
    });
    return true; // 保持消息通道开放
  } else if (message.type === 'DELETE_PROMPT') {
    deletePrompt(message.id);
  } else if (message.type === 'UPDATE_PROMPT') {
    updatePrompt(message.id, message.data);
  } else if (message.type === 'CLEAR_ALL_PROMPTS') {
    clearAllPrompts();
  }
});

// 保存提示词
async function savePrompt(promptData) {
  try {
    const result = await chrome.storage.local.get(['boltPrompts']);
    const prompts = result.boltPrompts || [];
    
    // 检查是否已存在相同的提示词（去重）
    const isDuplicate = prompts.some(p => 
      p.content.trim() === promptData.content.trim() && 
      Date.now() - p.timestamp < 60000 // 1分钟内的重复请求忽略
    );
    
    if (!isDuplicate && promptData.content.trim()) {
      const newPrompt = {
        id: Date.now().toString(),
        content: promptData.content.trim(),
        timestamp: Date.now(),
        url: promptData.url || 'bolt.new',
        wordCount: promptData.content.trim().split(/\s+/).length
      };
      
      prompts.unshift(newPrompt); // 新的在前面
      
      // 限制最多保存1000条记录
      if (prompts.length > 1000) {
        prompts.splice(1000);
      }
      
      await chrome.storage.local.set({ boltPrompts: prompts });
    }
  } catch (error) {
    console.error('保存提示词失败:', error);
  }
}

// 获取所有提示词
async function getPrompts() {
  try {
    const result = await chrome.storage.local.get(['boltPrompts']);
    return result.boltPrompts || [];
  } catch (error) {
    console.error('获取提示词失败:', error);
    return [];
  }
}

// 删除提示词
async function deletePrompt(id) {
  try {
    const result = await chrome.storage.local.get(['boltPrompts']);
    const prompts = result.boltPrompts || [];
    const filteredPrompts = prompts.filter(p => p.id !== id);
    await chrome.storage.local.set({ boltPrompts: filteredPrompts });
  } catch (error) {
    console.error('删除提示词失败:', error);
  }
}

// 更新提示词
async function updatePrompt(id, newData) {
  try {
    const result = await chrome.storage.local.get(['boltPrompts']);
    const prompts = result.boltPrompts || [];
    const index = prompts.findIndex(p => p.id === id);
    
    if (index !== -1) {
      prompts[index] = {
        ...prompts[index],
        ...newData,
        wordCount: newData.content ? newData.content.trim().split(/\s+/).length : prompts[index].wordCount
      };
      await chrome.storage.local.set({ boltPrompts: prompts });
    }
  } catch (error) {
    console.error('更新提示词失败:', error);
  }
}

// 清空所有提示词
async function clearAllPrompts() {
  try {
    await chrome.storage.local.set({ boltPrompts: [] });
  } catch (error) {
    console.error('清空提示词失败:', error);
  }
}