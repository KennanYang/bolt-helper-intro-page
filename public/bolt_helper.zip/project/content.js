// 内容脚本 - 监控Bolt.new页面的请求
(function() {
  'use strict';

  // 拦截XMLHttpRequest
  const originalXHROpen = XMLHttpRequest.prototype.open;
  const originalXHRSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function(method, url, ...args) {
    this._method = method;
    this._url = url;
    return originalXHROpen.apply(this, [method, url, ...args]);
  };

  XMLHttpRequest.prototype.send = function(data) {
    // 监控发送到Bolt API的请求
    if (this._url && (
      this._url.includes('/api/') || 
      this._url.includes('chat') || 
      this._url.includes('generate') ||
      this._url.includes('/v1/')
    )) {
      if (data && typeof data === 'string') {
        try {
          const parsedData = JSON.parse(data);
          extractAndSavePrompt(parsedData);
        } catch (e) {
          // 如果不是JSON格式，尝试直接提取文本
          if (data.length > 10 && data.length < 10000) {
            savePromptToBackground(data);
          }
        }
      }
    }
    
    return originalXHRSend.apply(this, arguments);
  };

  // 拦截fetch请求
  const originalFetch = window.fetch;
  window.fetch = function(url, options = {}) {
    if (typeof url === 'string' && (
      url.includes('/api/') || 
      url.includes('chat') || 
      url.includes('generate') ||
      url.includes('/v1/')
    )) {
      if (options.body) {
        try {
          if (typeof options.body === 'string') {
            const parsedData = JSON.parse(options.body);
            extractAndSavePrompt(parsedData);
          }
        } catch (e) {
          if (typeof options.body === 'string' && options.body.length > 10 && options.body.length < 10000) {
            savePromptToBackground(options.body);
          }
        }
      }
    }
    
    return originalFetch.apply(this, arguments);
  };

  // 从请求数据中提取提示词
  function extractAndSavePrompt(data) {
    let promptContent = '';
    
    // 常见的提示词字段名
    const promptFields = ['prompt', 'message', 'content', 'text', 'query', 'input', 'question'];
    
    // 递归搜索提示词内容
    function findPromptContent(obj, depth = 0) {
      if (depth > 5) return; // 防止无限递归
      
      if (typeof obj === 'string' && obj.length > 10) {
        promptContent = obj;
        return;
      }
      
      if (typeof obj === 'object' && obj !== null) {
        // 优先检查常见字段
        for (const field of promptFields) {
          if (obj[field] && typeof obj[field] === 'string' && obj[field].length > 10) {
            promptContent = obj[field];
            return;
          }
        }
        
        // 如果没找到，递归搜索所有字段
        for (const key in obj) {
          if (obj.hasOwnProperty(key)) {
            findPromptContent(obj[key], depth + 1);
            if (promptContent) return;
          }
        }
        
        // 检查数组中的最后一个元素（通常是最新的消息）
        if (Array.isArray(obj) && obj.length > 0) {
          findPromptContent(obj[obj.length - 1], depth + 1);
        }
      }
    }
    
    findPromptContent(data);
    
    if (promptContent && promptContent.length > 10) {
      savePromptToBackground(promptContent);
    }
  }

  // 发送提示词到后台脚本保存
  function savePromptToBackground(content) {
    if (content && content.trim().length > 10) {
      chrome.runtime.sendMessage({
        type: 'SAVE_PROMPT',
        data: {
          content: content.trim(),
          url: window.location.href,
          timestamp: Date.now()
        }
      });
    }
  }

  // 监控输入框变化（备用方案）
  function monitorInputFields() {
    const inputs = document.querySelectorAll('textarea, input[type="text"]');
    inputs.forEach(input => {
      if (!input._boltMonitored) {
        input._boltMonitored = true;
        input.addEventListener('blur', () => {
          if (input.value && input.value.length > 20) {
            // 延迟保存，避免保存用户正在编辑的内容
            setTimeout(() => {
              if (input.value === input._lastValue) return;
              input._lastValue = input.value;
              savePromptToBackground(input.value);
            }, 2000);
          }
        });
      }
    });
  }

  // 页面加载完成后开始监控
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', monitorInputFields);
  } else {
    monitorInputFields();
  }

  // 定期检查新的输入框
  setInterval(monitorInputFields, 3000);

})();