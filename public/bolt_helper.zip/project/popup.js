// 弹出页面的主要逻辑
class BoltPromptManager {
  constructor() {
    this.prompts = [];
    this.filteredPrompts = [];
    this.currentEditId = null;
    this.init();
  }

  // 初始化
  init() {
    this.bindEvents();
    this.loadPrompts();
  }

  // 绑定事件
  bindEvents() {
    // 搜索相关
    document.getElementById('searchBtn').addEventListener('click', () => {
      this.toggleSearch();
    });

    document.getElementById('closeSearchBtn').addEventListener('click', () => {
      this.closeSearch();
    });

    document.getElementById('searchInput').addEventListener('input', (e) => {
      this.handleSearch(e.target.value);
    });

    // 清空所有记录
    document.getElementById('clearAllBtn').addEventListener('click', () => {
      this.clearAllPrompts();
    });

    // 模态框相关
    document.getElementById('closeModalBtn').addEventListener('click', () => {
      this.closeModal();
    });

    document.getElementById('cancelEditBtn').addEventListener('click', () => {
      this.closeModal();
    });

    document.getElementById('saveEditBtn').addEventListener('click', () => {
      this.saveEdit();
    });

    // 点击遮罩关闭模态框
    document.querySelector('.modal-overlay').addEventListener('click', () => {
      this.closeModal();
    });

    // ESC键关闭模态框
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        this.closeModal();
        this.closeSearch();
      }
    });
  }

  // 加载提示词
  async loadPrompts() {
    this.showLoading();
    
    try {
      const response = await chrome.runtime.sendMessage({ type: 'GET_PROMPTS' });
      this.prompts = response.prompts || [];
      this.filteredPrompts = [...this.prompts];
      this.renderPrompts();
    } catch (error) {
      console.error('加载提示词失败:', error);
      this.showToast('加载失败，请重试');
    } finally {
      this.hideLoading();
    }
  }

  // 显示加载状态
  showLoading() {
    document.getElementById('loadingIndicator').classList.remove('hidden');
    document.getElementById('promptsList').classList.add('hidden');
    document.getElementById('emptyState').classList.add('hidden');
  }

  // 隐藏加载状态
  hideLoading() {
    document.getElementById('loadingIndicator').classList.add('hidden');
  }

  // 渲染提示词列表
  renderPrompts() {
    const promptsList = document.getElementById('promptsList');
    const emptyState = document.getElementById('emptyState');

    if (this.filteredPrompts.length === 0) {
      promptsList.classList.add('hidden');
      emptyState.classList.remove('hidden');
      return;
    }

    emptyState.classList.add('hidden');
    promptsList.classList.remove('hidden');

    promptsList.innerHTML = this.filteredPrompts.map(prompt => {
      const date = new Date(prompt.timestamp).toLocaleString('zh-CN', {
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
      });

      const contentPreview = prompt.content.length > 200 
        ? prompt.content.substring(0, 200) + '...'
        : prompt.content;

      const needsExpansion = prompt.content.length > 200;

      return `
        <div class="prompt-item" data-id="${prompt.id}">
          <div class="prompt-meta">
            <span class="prompt-date">${date}</span>
            <div class="prompt-stats">
              <span class="word-count">${prompt.wordCount} 词</span>
            </div>
          </div>
          <div class="prompt-content" data-full-content="${this.escapeHtml(prompt.content)}">
            ${this.escapeHtml(contentPreview)}
            ${needsExpansion ? '<button class="expand-btn">展开全文</button>' : ''}
          </div>
          <div class="prompt-actions">
            <button class="action-btn copy" data-action="copy">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                <path d="M5,15H4a2,2,0,0,1-2-2V4A2,2,0,0,1,4,2H15a2,2,0,0,1,2,2V5"></path>
              </svg>
              复制
            </button>
            <button class="action-btn edit" data-action="edit">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M11,4H4A2,2,0,0,0,2,6V20a2,2,0,0,0,2,2H16a2,2,0,0,0,2-2V13"></path>
                <path d="M18.5,2.5a2.12,2.12,0,0,1,3,3L12,15,8,16,9,12Z"></path>
              </svg>
              编辑
            </button>
            <button class="action-btn delete" data-action="delete">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="3,6 5,6 21,6"></polyline>
                <path d="M19,6V20a2,2,0,0,1-2,2H7a2,2,0,0,1-2-2V6M8,6V4a2,2,0,0,1,2-2h4a2,2,0,0,1,2,2V6"></path>
              </svg>
              删除
            </button>
          </div>
        </div>
      `;
    }).join('');

    // 绑定动作事件
    this.bindPromptActions();
  }

  // 绑定提示词操作事件
  bindPromptActions() {
    const promptsList = document.getElementById('promptsList');

    // 展开按钮事件
    promptsList.addEventListener('click', (e) => {
      if (e.target.classList.contains('expand-btn')) {
        const content = e.target.parentElement;
        const fullContent = content.dataset.fullContent;
        content.innerHTML = this.unescapeHtml(fullContent);
        content.classList.add('expanded');
      }
    });

    // 操作按钮事件
    promptsList.addEventListener('click', (e) => {
      if (e.target.closest('.action-btn')) {
        const btn = e.target.closest('.action-btn');
        const action = btn.dataset.action;
        const promptItem = btn.closest('.prompt-item');
        const promptId = promptItem.dataset.id;
        
        this.handlePromptAction(action, promptId);
      }
    });
  }

  // 处理提示词操作
  async handlePromptAction(action, promptId) {
    const prompt = this.prompts.find(p => p.id === promptId);
    if (!prompt) return;

    switch (action) {
      case 'copy':
        await this.copyPrompt(prompt.content);
        break;
      case 'edit':
        this.editPrompt(promptId, prompt.content);
        break;
      case 'delete':
        await this.deletePrompt(promptId);
        break;
    }
  }

  // 复制提示词
  async copyPrompt(content) {
    try {
      await navigator.clipboard.writeText(content);
      this.showToast('已复制到剪贴板');
    } catch (error) {
      console.error('复制失败:', error);
      this.showToast('复制失败');
    }
  }

  // 编辑提示词
  editPrompt(promptId, content) {
    this.currentEditId = promptId;
    document.getElementById('editTextarea').value = content;
    document.getElementById('editModal').classList.remove('hidden');
    document.getElementById('editTextarea').focus();
  }

  // 保存编辑
  async saveEdit() {
    const newContent = document.getElementById('editTextarea').value.trim();
    
    if (!newContent) {
      this.showToast('内容不能为空');
      return;
    }

    try {
      await chrome.runtime.sendMessage({
        type: 'UPDATE_PROMPT',
        id: this.currentEditId,
        data: { content: newContent }
      });

      this.closeModal();
      this.loadPrompts();
      this.showToast('保存成功');
    } catch (error) {
      console.error('保存失败:', error);
      this.showToast('保存失败');
    }
  }

  // 删除提示词
  async deletePrompt(promptId) {
    if (!confirm('确定要删除这条提示词吗？')) {
      return;
    }

    try {
      await chrome.runtime.sendMessage({
        type: 'DELETE_PROMPT',
        id: promptId
      });

      this.loadPrompts();
      this.showToast('删除成功');
    } catch (error) {
      console.error('删除失败:', error);
      this.showToast('删除失败');
    }
  }

  // 清空所有提示词
  async clearAllPrompts() {
    if (!confirm('确定要清空所有提示词记录吗？此操作不可恢复！')) {
      return;
    }

    try {
      await chrome.runtime.sendMessage({ type: 'CLEAR_ALL_PROMPTS' });
      this.loadPrompts();
      this.showToast('已清空所有记录');
    } catch (error) {
      console.error('清空失败:', error);
      this.showToast('清空失败');
    }
  }

  // 切换搜索
  toggleSearch() {
    const searchContainer = document.getElementById('searchContainer');
    const searchInput = document.getElementById('searchInput');
    
    if (searchContainer.classList.contains('hidden')) {
      searchContainer.classList.remove('hidden');
      setTimeout(() => searchInput.focus(), 300);
    } else {
      this.closeSearch();
    }
  }

  // 关闭搜索
  closeSearch() {
    const searchContainer = document.getElementById('searchContainer');
    const searchInput = document.getElementById('searchInput');
    
    searchContainer.classList.add('hidden');
    searchInput.value = '';
    this.filteredPrompts = [...this.prompts];
    this.renderPrompts();
  }

  // 处理搜索
  handleSearch(query) {
    if (!query.trim()) {
      this.filteredPrompts = [...this.prompts];
    } else {
      const lowerQuery = query.toLowerCase();
      this.filteredPrompts = this.prompts.filter(prompt =>
        prompt.content.toLowerCase().includes(lowerQuery)
      );
    }
    this.renderPrompts();
  }

  // 关闭模态框
  closeModal() {
    document.getElementById('editModal').classList.add('hidden');
    this.currentEditId = null;
  }

  // 显示提示信息
  showToast(message) {
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toastMessage');
    
    toastMessage.textContent = message;
    toast.classList.remove('hidden');
    
    setTimeout(() => {
      toast.classList.add('hidden');
    }, 3000);
  }

  // HTML转义
  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // HTML反转义
  unescapeHtml(html) {
    const div = document.createElement('div');
    div.innerHTML = html;
    return div.textContent || div.innerText || '';
  }
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
  new BoltPromptManager();
});