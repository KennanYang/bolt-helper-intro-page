// 后台脚本
chrome.runtime.onInstalled.addListener(() => {
  console.log('Bolt Prompt History 扩展已安装');
});

// 监听来自content script的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'PROMPT_SAVED') {
    // 可以在这里添加额外的处理逻辑
    console.log('收到新的提示词保存通知:', message.prompt);
  }
  
  return true;
});

// 处理存储变化
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local' && changes.promptHistory) {
    console.log('提示词历史已更新');
  }
});