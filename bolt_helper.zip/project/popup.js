class PromptHistoryManager {
  constructor() {
    this.prompts = [];
    this.filteredPrompts = [];
    this.currentEditId = null;
    this.init();
  }

  async init() {
    await this.loadPrompts();
    this.bindEvents();
    this.render();
  }

  async loadPrompts() {
    try {
      const result = await chrome.storage.local.get(['promptHistory']);
      this.prompts = result.promptHistory || [];
      this.filteredPrompts = [...this.prompts];
      this.updateStats();
    } catch (error) {
      console.error('加载提示词历史失败:', error);
    }
  }

  async savePrompts() {
    try {
      await chrome.storage.local.set({ promptHistory: this.prompts });
    } catch (error) {
      console.error('保存提示词历史失败:', error);
    }
  }

  bindEvents() {
    // 搜索功能
    const searchInput = document.getElementById('searchInput');
    const clearSearch = document.getElementById('clearSearch');
    
    searchInput.addEventListener('input', (e) => {
      this.handleSearch(e.target.value);
      clearSearch.style.display = e.target.value ? 'block' : 'none';
    });

    clearSearch.addEventListener('click', () => {
      searchInput.value = '';
      clearSearch.style.display = 'none';
      this.handleSearch('');
    });

    // 清空全部
    document.getElementById('clearAll').addEventListener('click', () => {
      this.handleClearAll();
    });

    // 导出数据
    document.getElementById('exportData').addEventListener('click', () => {
      this.handleExport();
    });

    // 模态框事件
    document.getElementById('closeModal').addEventListener('click', () => {
      this.hideModal();
    });

    document.getElementById('cancelEdit').addEventListener('click', () => {
      this.hideModal();
    });

    document.getElementById('saveEdit').addEventListener('click', () => {
      this.handleSaveEdit();
    });

    // 点击模态框外部关闭
    document.getElementById('editModal').addEventListener('click', (e) => {
      if (e.target.id === 'editModal') {
        this.hideModal();
      }
    });

    // ESC键关闭模态框
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        this.hideModal();
      }
    });
  }

  handleSearch(query) {
    const searchTerm = query.toLowerCase().trim();
    
    if (!searchTerm) {
      this.filteredPrompts = [...this.prompts];
    } else {
      this.filteredPrompts = this.prompts.filter(prompt => 
        prompt.content.toLowerCase().includes(searchTerm)
      );
    }
    
    this.render();
  }

  async handleClearAll() {
    if (this.prompts.length === 0) return;

    const confirmed = confirm('确定要清空所有提示词历史记录吗？此操作不可撤销。');
    if (confirmed) {
      this.prompts = [];
      this.filteredPrompts = [];
      await this.savePrompts();
      this.updateStats();
      this.render();
      this.showToast('已清空所有记录');
    }
  }

  handleExport() {
    if (this.prompts.length === 0) {
      this.showToast('没有数据可导出', 'warning');
      return;
    }

    const exportData = {
      exportTime: new Date().toISOString(),
      totalCount: this.prompts.length,
      prompts: this.prompts
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], {
      type: 'application/json'
    });

    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bolt-prompts-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    this.showToast('导出成功');
  }

  async handleCopy(id) {
    const prompt = this.prompts.find(p => p.id === id);
    if (!prompt) return;

    try {
      await navigator.clipboard.writeText(prompt.content);
      this.showToast('已复制到剪贴板');
    } catch (error) {
      console.error('复制失败:', error);
      this.showToast('复制失败', 'error');
    }
  }

  handleEdit(id) {
    const prompt = this.prompts.find(p => p.id === id);
    if (!prompt) return;

    this.currentEditId = id;
    document.getElementById('editTextarea').value = prompt.content;
    this.showModal();
  }

  async handleDelete(id) {
    const confirmed = confirm('确定要删除这条提示词记录吗？');
    if (!confirmed) return;

    this.prompts = this.prompts.filter(p => p.id !== id);
    this.filteredPrompts = this.filteredPrompts.filter(p => p.id !== id);
    
    await this.savePrompts();
    this.updateStats();
    this.render();
    this.showToast('删除成功');
  }

  async handleSaveEdit() {
    if (!this.currentEditId) return;

    const newContent = document.getElementById('editTextarea').value.trim();
    if (!newContent) {
      this.showToast('内容不能为空', 'error');
      return;
    }

    const promptIndex = this.prompts.findIndex(p => p.id === this.currentEditId);
    if (promptIndex !== -1) {
      this.prompts[promptIndex].content = newContent;
      this.prompts[promptIndex].updatedAt = Date.now();
      
      await this.savePrompts();
      
      // 更新过滤后的数组
      const filteredIndex = this.filteredPrompts.findIndex(p => p.id === this.currentEditId);
      if (filteredIndex !== -1) {
        this.filteredPrompts[filteredIndex] = { ...this.prompts[promptIndex] };
      }
      
      this.render();
      this.hideModal();
      this.showToast('保存成功');
    }
  }

  showModal() {
    document.getElementById('editModal').classList.add('show');
    document.getElementById('editTextarea').focus();
  }

  hideModal() {
    document.getElementById('editModal').classList.remove('show');
    this.currentEditId = null;
  }

  toggleExpand(id) {
    const contentEl = document.querySelector(`[data-id="${id}"] .prompt-content`);
    const expandBtn = document.querySelector(`[data-id="${id}"] .expand-btn`);
    
    if (contentEl.classList.contains('expanded')) {
      contentEl.classList.remove('expanded');
      expandBtn.textContent = '展开';
    } else {
      contentEl.classList.add('expanded');
      expandBtn.textContent = '收起';
    }
  }

  updateStats() {
    document.getElementById('promptCount').textContent = this.prompts.length;
  }

  render() {
    const container = document.getElementById('promptsList');
    const emptyState = document.getElementById('emptyState');

    if (this.filteredPrompts.length === 0) {
      container.innerHTML = '';
      emptyState.style.display = 'flex';
      return;
    }

    emptyState.style.display = 'none';
    
    // 按时间倒序排列
    const sortedPrompts = [...this.filteredPrompts].sort((a, b) => b.timestamp - a.timestamp);
    
    container.innerHTML = sortedPrompts.map(prompt => this.renderPromptItem(prompt)).join('');
    
    // 绑定事件
    this.bindPromptEvents();
  }

  renderPromptItem(prompt) {
    const date = new Date(prompt.timestamp);
    const timeStr = this.formatTime(date);
    const isLong = prompt.content.length > 200;
    const displayContent = isLong ? prompt.content.substring(0, 200) + '...' : prompt.content;

    return `
      <div class="prompt-item" data-id="${prompt.id}">
        <div class="prompt-header">
          <span class="prompt-time">${timeStr}</span>
          <div class="prompt-actions">
            <button class="prompt-btn copy" title="复制">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="9" y="9" width="13" height="13" rx="2" ry="2" stroke="currentColor" stroke-width="2"/>
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" stroke="currentColor" stroke-width="2"/>
              </svg>
            </button>
            <button class="prompt-btn edit" title="编辑">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" stroke="currentColor" stroke-width="2"/>
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" stroke="currentColor" stroke-width="2"/>
              </svg>
            </button>
            <button class="prompt-btn delete" title="删除">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <polyline points="3,6 5,6 21,6" stroke="currentColor" stroke-width="2"/>
                <path d="m19,6v14a2,2 0 0,1 -2,2H7a2,2 0 0,1 -2,-2V6m3,0V4a2,2 0 0,1 2,-2h4a2,2 0 0,1 2,2v2" stroke="currentColor" stroke-width="2"/>
              </svg>
            </button>
          </div>
        </div>
        <div class="prompt-content">${this.escapeHtml(displayContent)}</div>
        ${isLong ? '<button class="expand-btn">展开</button>' : ''}
      </div>
    `;
  }

  bindPromptEvents() {
    // 复制按钮
    document.querySelectorAll('.prompt-btn.copy').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.closest('.prompt-item').dataset.id;
        this.handleCopy(id);
      });
    });

    // 编辑按钮
    document.querySelectorAll('.prompt-btn.edit').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.closest('.prompt-item').dataset.id;
        this.handleEdit(id);
      });
    });

    // 删除按钮
    document.querySelectorAll('.prompt-btn.delete').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.closest('.prompt-item').dataset.id;
        this.handleDelete(id);
      });
    });

    // 展开按钮
    document.querySelectorAll('.expand-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.closest('.prompt-item').dataset.id;
        this.toggleExpand(id);
      });
    });
  }

  formatTime(date) {
    const now = new Date();
    const diff = now - date;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return '刚刚';
    if (minutes < 60) return `${minutes}分钟前`;
    if (hours < 24) return `${hours}小时前`;
    if (days < 7) return `${days}天前`;
    
    return date.toLocaleDateString('zh-CN', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  showToast(message, type = 'success') {
    // 移除现有的toast
    const existingToast = document.querySelector('.toast');
    if (existingToast) {
      existingToast.remove();
    }

    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    
    if (type === 'error') {
      toast.style.background = '#dc2626';
    } else if (type === 'warning') {
      toast.style.background = '#d97706';
    }

    document.body.appendChild(toast);

    setTimeout(() => {
      toast.remove();
    }, 3000);
  }
}

// 初始化
document.addEventListener('DOMContentLoaded', () => {
  new PromptHistoryManager();
});